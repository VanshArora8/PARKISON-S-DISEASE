"""Reusable preprocessing, training and evaluation helpers for the project."""
from pathlib import Path
import io
import numpy as np
import pandas as pd

from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix


def load_dataset(source):
    """Load CSV or comma-separated .data files."""
    if hasattr(source, "read"):
        raw = source.read()
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8-sig", errors="replace")
        source = io.StringIO(raw)
    path_name = str(getattr(source, "name", source)).lower()
    # The commonly used UCI parkinsons.data has a header and comma delimiters.
    df = pd.read_csv(source, sep=",")
    df.columns = [str(c).strip().replace("\ufeff", "") for c in df.columns]
    return df


def _find_target(columns):
    normalized = {str(c).strip().lower(): c for c in columns}
    for candidate in ("status", "target", "label", "class", "diagnosis", "parkinson", "parkinsons"):
        if candidate in normalized:
            return normalized[candidate]
    raise ValueError(
        "Target column not found. Expected a column such as 'status', 'target', 'label', "
        "'class', or 'diagnosis'. Please check the CSV header."
    )


def prepare_data(df):
    """Return numeric features, binary target, feature names and target column."""
    if df.empty:
        raise ValueError("The uploaded dataset is empty.")
    target = _find_target(df.columns)
    y_raw = df[target]
    if y_raw.isna().any():
        keep = y_raw.notna()
        df = df.loc[keep].copy()
        y_raw = df[target]

    y_values = pd.to_numeric(y_raw, errors="coerce")
    if y_values.isna().any():
        labels = y_raw.astype(str).str.strip().str.lower()
        mapping = {
            "healthy": 0, "control": 0, "no": 0, "negative": 0, "normal": 0,
            "parkinson": 1, "parkinsons": 1, "positive": 1, "yes": 1, "pd": 1
        }
        y_values = labels.map(mapping)
    if y_values.isna().any():
        raise ValueError("The target column must contain numeric 0/1 labels or recognizable healthy/control and Parkinson's labels.")

    unique = sorted(pd.Series(y_values).dropna().unique().tolist())
    if len(unique) != 2:
        raise ValueError(f"Expected a binary classification target with two classes; found {unique}.")
    if unique != [0, 1]:
        y_values = y_values.map({unique[0]: 0, unique[1]: 1})

    X = df.drop(columns=[target]).copy()
    # IDs/names are identifiers, not predictive measurements.
    for col in list(X.columns):
        if str(col).strip().lower() in {"name", "id", "patient_id", "patientid", "record_id"}:
            X = X.drop(columns=[col])
    X = X.apply(pd.to_numeric, errors="coerce")
    X = X.dropna(axis=1, how="all")
    if X.shape[1] == 0:
        raise ValueError("No numeric feature columns found after excluding identifiers and target.")
    if X.shape[0] < 10:
        raise ValueError("The dataset has fewer than 10 usable rows; more data is needed for a meaningful split.")
    if y_values.nunique() != 2 or y_values.value_counts().min() < 2:
        raise ValueError("Each target class needs at least two rows for a stratified train/test split.")
    return X, y_values.astype(int), list(X.columns), target


def build_models():
    """Return six supervised classifiers. Scaling is applied inside each pipeline."""
    def pipeline(estimator, scale=True):
        steps = [("imputer", SimpleImputer(strategy="median"))]
        if scale:
            steps.append(("scaler", StandardScaler()))
        steps.append(("model", estimator))
        return Pipeline(steps)

    return {
        "Logistic Regression": pipeline(LogisticRegression(max_iter=2000, class_weight=None)),
        "Random Forest": Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", RandomForestClassifier(n_estimators=300, random_state=42, class_weight="balanced"))
        ]),
        "Decision Tree": Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", DecisionTreeClassifier(random_state=42, class_weight="balanced"))
        ]),
        "Naive Bayes": pipeline(GaussianNB()),
        "K-Nearest Neighbors": pipeline(KNeighborsClassifier(n_neighbors=5)),
        "Support Vector Machine": pipeline(SVC(kernel="rbf", probability=True, class_weight="balanced", random_state=42)),
    }


def evaluate_models(models, X_train, X_test, y_train, y_test):
    rows, fitted = [], {}
    for name, model in models.items():
        model.fit(X_train, y_train)
        pred_train = model.predict(X_train)
        pred = model.predict(X_test)
        row = {
            "Model": name,
            "Train accuracy": accuracy_score(y_train, pred_train),
            "Test accuracy": accuracy_score(y_test, pred),
            "Precision (positive)": precision_score(y_test, pred, zero_division=0),
            "Recall (positive)": recall_score(y_test, pred, zero_division=0),
            "F1 (positive)": f1_score(y_test, pred, zero_division=0),
            "ROC AUC": np.nan,
        }
        try:
            if hasattr(model, "predict_proba"):
                row["ROC AUC"] = roc_auc_score(y_test, model.predict_proba(X_test)[:, 1])
            elif hasattr(model, "decision_function"):
                row["ROC AUC"] = roc_auc_score(y_test, model.decision_function(X_test))
        except ValueError:
            pass
        rows.append(row)
        fitted[name] = model
    return pd.DataFrame(rows), fitted


def make_confusion_matrix(y_true, y_pred):
    return confusion_matrix(y_true, y_pred, labels=[0, 1])


def get_feature_importance(pipeline, feature_names):
    """Extract tree feature importances or absolute linear coefficients when available."""
    estimator = pipeline.named_steps.get("model")
    if estimator is None:
        return None
    if hasattr(estimator, "feature_importances_"):
        values = estimator.feature_importances_
    elif hasattr(estimator, "coef_") and estimator.coef_.ndim == 2:
        values = np.abs(estimator.coef_[0])
    else:
        return None
    if len(values) != len(feature_names):
        return None
    return pd.DataFrame({"feature": feature_names, "importance": values}).sort_values("importance", ascending=False)
