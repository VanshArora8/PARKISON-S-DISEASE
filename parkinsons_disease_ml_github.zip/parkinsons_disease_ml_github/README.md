# Parkinson's Disease Detection Using Machine Learning

A recreated, GitHub-ready implementation based on the uploaded project report **“Detection of Parkinson’s Disease Using Machine Learning Algorithm.”** The original source-code files and dataset were not included in the PDF, so this is a clean reconstruction of the described workflow rather than a recovery of the exact lost code.

## Features

- Upload a CSV or comma-separated `.data` dataset through a Streamlit interface.
- Preview the dataset and inspect missing values and summary statistics.
- Recognize common binary target-column names such as `status`, `target`, `label`, `class`, or `diagnosis`.
- Exclude common identifier fields such as `name` and `id` from model inputs.
- Handle missing feature values using median imputation.
- Use a reproducible stratified train/test split (default: 80% train / 20% test, matching the implementation section of the report).
- Train and compare six classifiers:
  - Logistic Regression
  - Random Forest
  - Decision Tree
  - Gaussian Naive Bayes
  - K-Nearest Neighbors (KNN)
  - Support Vector Machine (SVM)
- Show accuracy, precision, recall, F1-score, ROC AUC, confusion matrix, classification report, and supported feature-importance charts.
- Download the model-comparison table as CSV.

## Project structure

```text
parkinsons_disease_ml_github/
├── app.py
├── src/
│   ├── __init__.py
│   └── parkinsons_ml.py
├── data/
│   └── .gitkeep
├── requirements.txt
├── .gitignore
└── README.md
```

## Requirements

- Python 3.10 or newer recommended
- Internet access for installing dependencies
- A compatible Parkinson's dataset in CSV or comma-separated `.data` format

## Run locally

### Windows (PowerShell)

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

Open the local URL printed by Streamlit. Upload your dataset in the sidebar/main page file uploader.

## Dataset

The report says the dataset was obtained from Kaggle, but it does not identify an exact downloadable file in the text. A commonly used public source is the [UCI Parkinson's dataset](https://archive.ics.uci.edu/dataset/174/parkinsons). Check the dataset's license and terms before redistributing it.

For automatic local loading, save a compatible file as:

```text
data/parkinsons.data
```

The app expects a binary target column. The common voice dataset uses `status`, where `1` and `0` represent the two classes. Keep the original dataset's header row. You can also upload a CSV directly in the app.

**Do not commit private patient data to GitHub.** Only publish data you have permission to share.

## Push to GitHub

1. Create a new empty repository on GitHub.
2. Extract this ZIP folder.
3. Open a terminal inside the extracted folder.
4. Run:

```bash
git init
git add .
git commit -m "Add Parkinson's disease ML project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Replace the remote URL with your repository's actual URL. Do not share passwords or access tokens.

## Notes about the results

The PDF report describes Random Forest test accuracy of about 92.31%, SVM around 87%, Logistic Regression around 87%, KNN around 84.6%, and a Decision Tree result of 100%. These numbers are report-specific; results from this recreated code can differ depending on the dataset version, split, and preprocessing. A 100% result should be checked carefully for overfitting, data leakage, or a small test set.

## Medical disclaimer

This is an academic classification demonstration, not a validated clinical device. It must not be used to diagnose Parkinson's disease or make treatment decisions. Model performance on one dataset does not establish clinical reliability.
