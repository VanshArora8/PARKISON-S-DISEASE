from pathlib import Path
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns

from src.parkinsons_ml import (
    load_dataset, prepare_data, build_models, evaluate_models,
    make_confusion_matrix, get_feature_importance
)

st.set_page_config(page_title="Parkinson's Disease Detection", page_icon="🧠", layout="wide")
st.title("🧠 Parkinson's Disease Detection Using Machine Learning")
st.caption("Educational machine-learning demonstration based on voice-feature data. This is not a medical diagnostic tool.")

st.warning(
    "This project is for academic use only. Predictions must not be used to diagnose, rule out, or treat Parkinson's disease. "
    "Consult a qualified healthcare professional for medical concerns."
)

uploaded = st.file_uploader("Upload a Parkinson's dataset (CSV)", type=["csv", "data", "txt"])
default_path = Path("data/parkinsons.data")

df = None
try:
    if uploaded is not None:
        df = load_dataset(uploaded)
        source_name = uploaded.name
    elif default_path.exists():
        df = load_dataset(default_path)
        source_name = str(default_path)
    else:
        st.info(
            "Upload your dataset to begin. The usual UCI/Kaggle Parkinson's voice dataset contains a target column named "
            "`status` (1 = Parkinson's group, 0 = control group). Place a licensed copy at "
            "`data/parkinsons.data` to load it automatically."
        )
        st.markdown("[UCI Parkinson's dataset information](https://archive.ics.uci.edu/dataset/174/parkinsons)")
        st.stop()
except Exception as exc:
    st.error(f"Could not read the dataset: {exc}")
    st.stop()

st.subheader("1. Dataset preview")
st.write(f"Loaded: **{source_name}**")
st.dataframe(df.head(10), use_container_width=True)
c1, c2, c3 = st.columns(3)
c1.metric("Rows", f"{df.shape[0]:,}")
c2.metric("Columns", f"{df.shape[1]:,}")
c3.metric("Missing cells", f"{int(df.isna().sum().sum()):,}")

with st.expander("Dataset summary"):
    st.dataframe(df.describe(include="all").transpose(), use_container_width=True)
    st.write("Missing values by column")
    st.dataframe(df.isna().sum().rename("missing values"))

try:
    X, y, feature_names, target_name = prepare_data(df)
except Exception as exc:
    st.error(str(exc))
    st.stop()

st.subheader("2. Train and compare models")
test_size = st.slider("Test set size (%)", min_value=20, max_value=40, value=20, step=5)
random_state = st.number_input("Random seed (for reproducibility)", min_value=0, max_value=99999, value=42)
if st.button("Train models", type="primary"):
    from sklearn.model_selection import train_test_split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size / 100, random_state=int(random_state), stratify=y
    )
    models = build_models()
    results, fitted_models = evaluate_models(models, X_train, X_test, y_train, y_test)

    st.session_state["results"] = results
    st.session_state["fitted_models"] = fitted_models
    st.session_state["X_test"] = X_test
    st.session_state["y_test"] = y_test
    st.session_state["X_train"] = X_train
    st.session_state["y_train"] = y_train
    st.session_state["feature_names"] = feature_names
    st.session_state["target_name"] = target_name

if "results" in st.session_state:
    results = st.session_state["results"]
    fitted_models = st.session_state["fitted_models"]
    X_test = st.session_state["X_test"]
    y_test = st.session_state["y_test"]
    feature_names = st.session_state["feature_names"]

    st.subheader("3. Model comparison")
    st.dataframe(results.sort_values("Test accuracy", ascending=False).style.format({
        "Train accuracy": "{:.3f}", "Test accuracy": "{:.3f}",
        "Precision (positive)": "{:.3f}", "Recall (positive)": "{:.3f}",
        "F1 (positive)": "{:.3f}", "ROC AUC": "{:.3f}"
    }), use_container_width=True)

    selected = st.selectbox("Inspect model", list(fitted_models.keys()),
                             index=list(fitted_models.keys()).index(
                                 results.sort_values("Test accuracy", ascending=False).iloc[0]["Model"]))
    model = fitted_models[selected]
    y_pred = model.predict(X_test)

    left, right = st.columns(2)
    with left:
        st.markdown("**Confusion matrix**")
        cm = make_confusion_matrix(y_test, y_pred)
        fig, ax = plt.subplots()
        sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", cbar=False, ax=ax)
        ax.set_xlabel("Predicted label")
        ax.set_ylabel("Actual label")
        st.pyplot(fig)
        plt.close(fig)

    with right:
        st.markdown("**Classification report**")
        from sklearn.metrics import classification_report
        report = classification_report(y_test, y_pred, output_dict=True, zero_division=0)
        st.dataframe(pd.DataFrame(report).transpose().round(3), use_container_width=True)

    try:
        from sklearn.metrics import roc_curve, roc_auc_score
        if hasattr(model, "predict_proba"):
            scores = model.predict_proba(X_test)[:, 1]
        elif hasattr(model, "decision_function"):
            scores = model.decision_function(X_test)
        else:
            scores = None
        if scores is not None and len(set(y_test)) == 2:
            fpr, tpr, _ = roc_curve(y_test, scores)
            auc = roc_auc_score(y_test, scores)
            st.markdown("**ROC curve**")
            fig, ax = plt.subplots()
            ax.plot(fpr, tpr, label=f"AUC = {auc:.3f}")
            ax.plot([0, 1], [0, 1], linestyle="--")
            ax.set_xlabel("False positive rate")
            ax.set_ylabel("True positive rate")
            ax.legend()
            st.pyplot(fig)
            plt.close(fig)
    except Exception as exc:
        st.info(f"ROC curve unavailable for this dataset: {exc}")

    importance = get_feature_importance(model, feature_names)
    if importance is not None:
        st.markdown("**Most influential features (where supported by the model)**")
        importance = importance.head(15).sort_values("importance")
        fig, ax = plt.subplots(figsize=(8, 5))
        ax.barh(importance["feature"], importance["importance"])
        ax.set_xlabel("Importance")
        st.pyplot(fig)
        plt.close(fig)

    csv = results.to_csv(index=False).encode("utf-8")
    st.download_button("Download model comparison (CSV)", csv, "model_comparison.csv", "text/csv")

st.subheader("4. Exploratory analysis")
numeric = df.select_dtypes(include="number")
if not numeric.empty:
    col = st.selectbox("Choose a numeric column for its distribution", numeric.columns)
    fig, ax = plt.subplots()
    ax.hist(numeric[col].dropna(), bins=25, edgecolor="black")
    ax.set_title(f"Distribution of {col}")
    ax.set_xlabel(col)
    ax.set_ylabel("Frequency")
    st.pyplot(fig)
    plt.close(fig)

st.caption("Models: Logistic Regression, Random Forest, Decision Tree, Gaussian Naive Bayes, KNN, and Support Vector Machine.")
